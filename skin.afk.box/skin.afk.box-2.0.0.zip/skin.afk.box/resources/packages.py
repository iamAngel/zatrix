############################################################################
#
#  Copyright 2014 Wilfred Helmig - kaosBOX
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
############################################################################


import xbmc, xbmcgui
import shutil

localtxt1 = 'Add-Ons Opschonen'
localtxt2 = 'Add-ons Opschonen geslaagd'
localtxt3 = 'Weet u zeker dat u de add-ons wilt opschonen?'

destpath=xbmc.translatePath(os.path.join('special://home/addons/packages',''))

class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno(localtxt1, localtxt3):
      shutil.rmtree(destpath)
      os.mkdir(destpath)
      self.close()

      xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Onderhoud)")


mydisplay = MyClass()
del mydisplay

