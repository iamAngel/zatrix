#!/bin/sh
#xbmc-send -a "Notification(afkboxscript.sh:,'$1')"
#xbmc-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  xbmc-send -a "Notification(Verwerken van Opdracht:,$1,$TIME,/storage/.xbmc/addons/skin.afk.box/resources/afkboxscript.png)" &> /dev/null
  echo $1
}

mountUSB(){
	mkdir /storage/USB
	mount /dev/sda1 /storage/USB
}

umountUSB(){
	umount /storage/USB
	rmdir /storage/USB
}

mountSD(){
	mkdir /storage/SD
	mount /dev/mmcblk0p2 /storage/SD
}

umountSD(){
	umount /storage/SD
	rmdir /storage/SD
}

checkUSB(){
	USB=$(df | grep /dev/sda)
	if [[ "$USB" == "" ]]; then
		myInfo 'geen USB apparaat gevonden!'
		exit
	fi
}


if [[ "$1" == "runSD" ]]; then
	myInfo 'herstarten van SD kaart'
	mount -o remount,rw /flash
	cp /storage/scripts/cmdlineSD.txt /flash/cmdline.txt
	sleep 1
	reboot
fi

if [[ "$1" == "runUSB" ]]; then
	checkUSB
	mountUSB
	if [ ! -d "/storage/USB/.xbmc" ]; then
  		myInfo 'error: geen AFK-Software op USB device!'
		umountUSB
		exit
	fi
	umountUSB
	myInfo 'herstarten van USB device'
	mount -o remount,rw /flash
	cp /storage/scripts/cmdlineUSB.txt /flash/cmdline.txt
	sleep 1
	reboot
fi

if [[ "$1" == "SD2USB" ]]; then
	checkUSB
	myInfo 'Kopieer AFK-Box van SD kaart naar USB device' 600
	mountUSB
	cd /storage/
	tar cf - . --exclude=./USB --exclude=./.xbmc/userdata/Thumbnails --exclude=./.xbmc/userdata/Database/Textures13.db --exclude=./.cache/ssh --exclude=./.xbmc/addons/packages | ( cd './USB/'; tar xfp -)
	cp /storage/scripts/SkinSettingsUSB.xml /storage/USB/.xbmc/addons/skin.afk.box/720p/SkinSettings.xml
	umountUSB
	myInfo 'AFK-Box is gekopieerd naar USB apparaat!'
fi


if [[ "$1" == "USB2SD" ]]; then
	checkUSB
	myInfo 'kopieer AFK-Box van USB apparaat naar SD kaart' 600
	mountSD
	cd /storage/
	tar cf - . --exclude=./SD --exclude=./.xbmc/userdata/Thumbnails --exclude=./.xbmc/userdata/Database/Textures13.db --exclude=./.cache/ssh --exclude=./.xbmc/addons/packages | ( cd './SD/'; tar xfp -)
	cp /storage/scripts/SkinSettingsSD.xml /storage/SD/.xbmc/addons/skin.afk.box/720p/SkinSettings.xml
	umountSD
	myInfo 'AFK-Box is gekopieerd naar SD kaart!'
fi


if [[ "$1" == "USBfat" ]]; then
	checkUSB
	myInfo 'formatteren USB voor Windows (fat32)' 120
	umount /dev/sda1 &> /dev/null
	umount /dev/sda2 &> /dev/null
#	parted -s /dev/sda rm 1 rm 2
	dd if=/dev/zero of=/dev/sda bs=1M count=10 &> /dev/null
	parted /dev/sda mklabel msdos &> /dev/null
	parted -s -a optimal /dev/sda mkpart primary fat32 1 100% &> /dev/null
	mkfs.vfat -n "windows" -I /dev/sda1
	eject /dev/sda
	sleep 1
	eject -t /dev/sda
	myInfo 'USB apparaat is geformatteerd|!'
fi


if [[ "$1" == "USBext" ]]; then
	checkUSB
	myInfo 'formatteren USB(ext4)' 120
	umount /dev/sda1 &> /dev/null
	umount /dev/sda2 &> /dev/null
#	sleep 1
#	parted -s /dev/sda rm 1 rm 2
	dd if=/dev/zero of=/dev/sda bs=1M count=10 &> /dev/null
	parted /dev/sda mklabel msdos
	parted -s -a optimal /dev/sda mkpart primary ext4 1 100% &> /dev/null
	mkfs.ext4 -L "storage" /dev/sda1
	eject /dev/sda
	sleep 1
	eject -t /dev/sda
	myInfo 'USB apparaat is geformatteerd voor Installatie!'
fi

if [[ "$1" == "standaard" ]]; then
	myInfo 'Standaard Config'
	mount -o remount,rw /flash
	cp /storage/scripts/SkinSettingsA.xml /storage/.xbmc/addons/skin.afk.box/720p/SkinSettings.xml
	cp /storage/scripts/configdefault.txt /flash/config.txt
	sleep 1
	reboot
fi

if [[ "$1" == "speed2" ]]; then
	myInfo 'Turbo 2 Config'
	mount -o remount,rw /flash
	cp /storage/scripts/SkinSettingsB.xml /storage/.xbmc/addons/skin.afk.box/720p/SkinSettings.xml
	cp /storage/scripts/config1000.txt /flash/config.txt
	sleep 1
	reboot
fi

if [[ "$1" == "speed4" ]]; then
	myInfo 'Turbo 4 Config'
	mount -o remount,rw /flash
	cp /storage/scripts/SkinSettingsC.xml /storage/.xbmc/addons/skin.afk.box/720p/SkinSettings.xml
	cp /storage/scripts/config1100.txt /flash/config.txt
	sleep 1
	reboot
fi

