import xbmc, xbmcgui
import shutil
import urllib2,urllib
import time
import os

localtxt2 = 'Installeren voltooid! Herstarten AFK-Box'
localtxt3 = 'Verwerken. Even geduld a.u.b.!'
localtxt4 = 'Verwerken. Bijna klaar!'

def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("VPN Manager installeren","Downloaden & uitpakken van het bestand. Even geduld a.u.b.",'')
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print 'Gedownload '+str(percent)+'%'
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        print "DOWNLOAD GEANNULEERD" # need to get this part working
        dp.close()

class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("VPN Manager installeren","","Weet u zeker dat u VPN Manager wilt installeren?"):
        url = 'http://backups.allefilmskijken.com/vpnpack.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, 'vpnpack.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('storage/',''))
        xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))

 	xbmc.executebuiltin("Notification("+localtxt3+",AFK-Box Installer)")
        time.sleep(10)
	xbmc.executebuiltin("Notification("+localtxt4+",AFK-Box Installer)")
        time.sleep(10)
   	xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Installer)")
        time.sleep(10)
   	xbmc.executebuiltin('Reboot')

mydisplay = MyClass()
del mydisplay