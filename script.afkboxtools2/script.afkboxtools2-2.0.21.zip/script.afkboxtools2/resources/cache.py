############################################################################
#
#  Copyright 2015 AFK-Box
#
############################################################################


import xbmc, xbmcgui,os
import shutil
import os


localtxt1 = "Verwijder van de Cache Opslag"
localtxt2 = "Alle cache/temp bestanden zijn verwijderd"
localtxt3 = "Weet u het zeker?"
localtxt4 = "Verwijder cache/temp bestanden en van de AFK-Box."


class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno(localtxt1, localtxt4 ,"",localtxt3):
      xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
      if os.path.exists(xbmc_cache_path)==True:
              for root, dirs, files in os.walk(xbmc_cache_path):
                      file_count = 0
                      file_count += len(files)

              # Count files and give option to delete
                      if file_count > 0:

                              dialog = xbmcgui.Dialog()
                              if dialog.yesno("Verwijder Kodi cache bestanden", str(file_count) + " bestanden gevonden", "U wilt deze verwijderen?"):

                                      for f in files:
                                              os.unlink(os.path.join(root, f))
                                      for d in dirs:
                                              shutil.rmtree(os.path.join(root, d))

                      else:
                              pass


      temp_cache_path = os.path.join(xbmc.translatePath('special://temp'), '')
      if os.path.exists(temp_cache_path)==True:
              for root, dirs, files in os.walk(temp_cache_path):
                      file_count = 0
                      file_count += len(files)

              # Count files and give option to delete
                      if file_count > 0:

                              dialog = xbmcgui.Dialog()
                              if dialog.yesno("Verwijder temp bestanden", str(file_count) + " bestanden gevonden", "U wilt deze verwijderen?"):

                                      for f in files:
                                              os.unlink(os.path.join(root, f))
                                      for d in dirs:
                                              shutil.rmtree(os.path.join(root, d))

                      else:
                              pass

      # Set path to Pulsar cache files
      pls_cache_path = os.path.join(xbmc.translatePath('var/media/STORAGE2'), '')
      if os.path.exists(pls_cache_path)==True:
              for root, dirs, files in os.walk(pls_cache_path):
                      file_count = 0
                      file_count += len(files)

              # Count files and give option to delete
                      if file_count > 0:

                              dialog = xbmcgui.Dialog()
                              if dialog.yesno("Verwijder pulsar bestanden", str(file_count) + " bestanden gevonden", "U wilt deze verwijderen?"):

                                      for f in files:
                                              os.unlink(os.path.join(root, f))
                                      for d in dirs:
                                              shutil.rmtree(os.path.join(root, d))

                      else:
                              pass

      xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Onderhoud)")


mydisplay = MyClass()
del mydisplay

