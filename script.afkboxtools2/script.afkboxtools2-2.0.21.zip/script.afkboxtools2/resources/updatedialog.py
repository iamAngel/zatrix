import xbmcgui

ok = xbmcgui.Dialog().ok('Controleren op Addon Updates gestart!','Aan de hand van de aantal updates kan dit enkele minuten in beslag nemen.','[B][COLOR=green]U kunt uw systeem normaal gebruiken.[/COLOR][/B]')