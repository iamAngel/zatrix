#!/bin/sh
#kodi-send -a "Notification(afkboxscript.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(Verwerken van Opdracht:,$1,$TIME,/storage/.kodi/addons/script.afkboxtools2/resources/afkboxscript.png)" &> /dev/null
  echo $1
}

checkUSB(){
	USB=$(df | grep /dev/sda)
	if [[ "$USB" == "" ]]; then
		myInfo 'geen USB apparaat gevonden!'
		exit
	fi
}

if [[ "$1" == "clean" ]]; then
	myInfo 'Opschonen verouderde addons'
	rm -rf /var/media/STORAGE2/*
	rm -rf '/storage/.kodi/addons/plugin.audio.spotify'
	rm -rf '/storage/.kodi/addons/plugin.video.titan'
	rm -rf '/storage/.kodi/addons/plugin.video.dss'
	rm -rf '/storage/.kodi/addons/plugin.video.genesis'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.audio.spotify'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.titan'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.dss'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.genesis'
	sleep 5
	myInfo 'Add-ons Opschonen geslaagd'
fi

if [[ "$1" == "cleanthumb" ]]; then
	myInfo 'Afbeeldingen verwijderen'
	rm /storage/.kodi/userdata/Database/Textures13.db
	rm -rf /storage/.kodi/userdata/Thumbnails/*
	sleep 3
	myInfo 'Afbeeldingen verwijderd - AFK-Box herstart nu!'
	sleep 3
    reboot
fi

if [[ "$1" == "addondel" ]]; then
	myInfo 'Database verwijderen'
	rm /storage/.kodi/userdata/Database/Addons19.db
	sleep 3
	myInfo 'Database verwijderd - AFK-Box herstart nu!'
	sleep 3
    reboot
fi

if [[ "$1" == "update" ]]; then
	myInfo 'Instellingen Updaten'
	rm -rf '/storage/.kodi/addons/repository.pulsarunofficial'
	rm -rf '/storage/.kodi/addons/plugin.video.nlview'
	rm -rf '/storage/.kodi/addons/plugin.video.AwesomeStreams'
	rm -rf '/storage/.kodi/addons/plugin.video.sportcenterhd'
	rm -rf '/storage/.kodi/addons/plugin.program.totalinstaller'
	rm -rf '/storage/.kodi/addons/plugin.video.legacycainstaller'
	mount -o remount,rw /flash
	cd /storage/.kodi/addons/packages
	wget http://backups.allefilmskijken.com/settings/screen.zip
	sleep 6
	myInfo 'Moment geduld AUB!'
	unzip -o screen.zip -d /flash
	sleep 3
	myInfo 'Instellingen Updated - AFK-Box herstart nu!'
	sleep 3
	reboot
fi

if [[ "$1" == "updateS" ]]; then
	myInfo 'Instellingen Updaten'
	rm -rf '/storage/.kodi/addons/repository.pulsarunofficial'
	rm -rf '/storage/.kodi/addons/plugin.video.nlview'
	rm -rf '/storage/.kodi/addons/plugin.video.AwesomeStreams'
	rm -rf '/storage/.kodi/addons/plugin.video.sportcenterhd'
	rm -rf '/storage/.kodi/addons/plugin.program.totalinstaller'
	rm -rf '/storage/.kodi/addons/plugin.video.legacycainstaller'
	mount -o remount,rw /flash
	cd /storage/.kodi/addons/packages
	wget http://backups.allefilmskijken.com/settings/screen.zip
	sleep 6
	myInfo 'Moment geduld AUB!'
	unzip -o screen.zip -d /flash
	sleep 3
	myInfo 'Instellingen Updated - AFK-Box herstart nu!'
	sleep 3
    reboot
fi


if [[ "$1" == "bestuurup60" ]]; then
    cd /storage/.kodi/addons/packages
	sleep 6
	myInfo 'Moment geduld AUB!'
	unzip -o updatebestuurpack.zip -d /storage
	sleep 6
	myInfo 'Moment geduld AUB!'
	sleep 6
	myInfo 'Moment geduld AUB!'
	cp /storage/backup/BackupAFKb0x11.tar /storage/.restore/BackupAFKb0x11.tar
	sleep 10
	myInfo 'Moment geduld AUB!'
	sleep 6
    cp /storage/.kodi/userdata/addon_data/plugin.video.genesis/favourites.db /storage/favourites.db
	sleep 3
	myInfo 'Moment geduld AUB!'
	update http://gettv.nl/downloadafk/OpenELEC-Amlogic.arm-M8-6.0.0.1-update.zip
	sleep 20
	cd /storage/.kodi/addons/packages
	wget http://gettv.nl/downloadafk/update/updatem8.zip
	sleep 20
	myInfo 'Moment geduld AUB!'
	unzip -o updatem8.zip -d /storage
	sleep 20
	reboot
fi

if [[ "$1" == "backup" ]]; then
	myInfo 'Herinstallatie AFK-Box'
	cp /storage/backup/BackupAFKb0x11.tar /storage/.restore/BackupAFKb0x11.tar
	sleep 15
	myInfo 'Herinstallatie Bijna klaar!'
	sleep 15
	myInfo 'Herinstallatie Voltooid - AFK-Box herstart nu!'
	sleep 15
	reboot
fi

if [[ "$1" == "favba" ]]; then
	myInfo 'Favorieten Backupen'
	cp /storage/.kodi/userdata/addon_data/plugin.video.genesis/favourites.db /storage/favourites.db
	sleep 3
	myInfo 'Favorieten zijn gebackupt!'
fi

if [[ "$1" == "favre" ]]; then
	myInfo 'Favorieten Herstellen'
	cp /storage/favourites.db /storage/.kodi/userdata/addon_data/plugin.video.genesis/favourites.db
	cp /storage/.kodi/userdata/addon_data/plugin.video.genesis/favourites.db /storage/.kodi/userdata/addon_data/plugin.video.specto/favourites.db
	sleep 3
	myInfo 'Favorieten zijn hersteld!'
fi

if [[ "$1" == "usbext" ]]; then
	checkUSB
    umount /dev/sda[1-2]
    myInfo 'formateren USB (ext4) moment geduld'
    parted -s /dev/sda mklabel msdos
    parted -s -a optimal /dev/sda mkpart primary ext4 1 100%
    mkfs.ext4 -L "STORAGE2" /dev/sda1
    eject /dev/sda
	sleep 1
	eject -t /dev/sda
	sleep 5
    myInfo 'USB apparaat is aangepast!'
fi

if [[ "$1" == "vierkant" ]]; then
	myInfo 'AFK-Box remote voorbereiden'
	sleep 6
	unzip -o /storage/.kodi/addons/script.afkboxtools2/resources/settings1.zip -d /storage
	myInfo 'Afk-Box  remote ingesteld! - Herstarten'
	sleep 6
	reboot
fi

if [[ "$1" == "ovaal" ]]; then
	myInfo 'AFK-Box remote voorbereiden'
	sleep 6
	unzip -o /storage/.kodi/addons/script.afkboxtools2/resources/settings.zip -d /storage
	myInfo 'Afk-Box  remote ingesteld! - Herstarten'
	sleep 6
	reboot
fi

if [[ "$1" == "ab1" ]]; then
	myInfo 'AFK-Box remote voorbereiden'
	sleep 6
	unzip -o /storage/.kodi/addons/script.afkboxtools2/resources/settingsv8ori.zip -d /storage
	myInfo 'Afk-Box  remote ingesteld! - Herstarten'
	sleep 6
	reboot
fi

if [[ "$1" == "ab2" ]]; then
	myInfo 'AFK-Box remote voorbereiden'
	sleep 6
	unzip -o /storage/.kodi/addons/script.afkboxtools2/resources/settingsv8.zip -d /storage
	myInfo 'Afk-Box  remote ingesteld! - Herstarten'
	sleep 6
	reboot
fi


if [[ "$1" == "dwlbckup" ]]; then
	myInfo 'AFK-Box Herstarten'
	mount -o remount,rw /flash
	cd /storage/.kodi/addons/packages
	wget http://backups.allefilmskijken.com/settings/screen.zip
	sleep 4
	myInfo 'Herstarten over 5!'
	sleep 10
	myInfo 'Herstarten over 4!'
	sleep 10
	myInfo 'Herstarten over 3!'
	unzip -o screen.zip -d /flash
	sleep 10
	myInfo 'Herstarten over 2!'
	sleep 10
	myInfo 'Herstarten over 1!'
	sleep 10
	myInfo 'AFK-Box herstart nu moment geduld!'
	sleep 6
	reboot
fi

if [[ "$1" == "bestuurupdate60" ]]; then
    cd /storage/.kodi/addons/packages
	sleep 6
	myInfo 'Moment geduld AUB!'
	unzip -o updatebestuurpack.zip -d /storage
	sleep 6
	myInfo 'Moment geduld AUB!'
	sleep 6
	myInfo 'Moment geduld AUB!'
	cp /storage/backup/BackupAFKb0x11.tar /storage/.restore/BackupAFKb0x11.tar
	sleep 10
	myInfo 'Moment geduld AUB!'
	sleep 6
    cp /storage/.kodi/userdata/addon_data/plugin.video.genesis/favourites.db /storage/favourites.db
	sleep 3
	myInfo 'Moment geduld AUB!'
	update http://backups.allefilmskijken.com/update/OpenELEC-Amlogic.arm-M8-6.0.0.1-update.zip
	sleep 20
	cd /storage/.kodi/addons/packages
	wget http://backups.allefilmskijken.com/update/updatem8.zip
	sleep 20
	myInfo 'Moment geduld AUB!'
	unzip -o updatem8.zip -d /storage
	sleep 20
	reboot
fi