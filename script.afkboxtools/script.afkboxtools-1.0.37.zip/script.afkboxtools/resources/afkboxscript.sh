#!/bin/sh
#kodi-send -a "Notification(afkboxscript.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(Verwerken van Opdracht:,$1,$TIME,/storage/.kodi/addons/script.afkboxtools/resources/afkboxscript.png)" &> /dev/null
  echo $1
}

if [[ "$1" == "standaard" ]]; then
	myInfo 'Standaard Config'
	mount -o remount,rw /flash
	cp /storage/.kodi/addons/script.afkboxtools/resources/SkinSettingsA.xml /storage/.kodi/addons/skin.afk.box/720p/SkinSettings.xml
	cp /storage/.kodi/addons/script.afkboxtools/resources/configdefault.txt /flash/config.txt
	sleep 3
	myInfo 'Standaard Config Geactiveerd - AFK-Box herstart nu!'
	sleep 3
	reboot
fi

if [[ "$1" == "turbo" ]]; then
	myInfo 'Turbo Config'
	mount -o remount,rw /flash
	cp /storage/.kodi/addons/script.afkboxtools/resources/SkinSettingsB.xml /storage/.kodi/addons/skin.afk.box/720p/SkinSettings.xml
	cp /storage/.kodi/addons/script.afkboxtools/resources/turbo.txt /flash/config.txt
	sleep 3
	myInfo 'Turbo Config Geactiveerd - AFK-Box herstart nu!'
	sleep 3
	reboot
fi

if [[ "$1" == "update" ]]; then
	myInfo 'Instellingen Updaten'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.genesis'
	rm -rf '/storage/.kodi/addons/repository.pulsarunofficial'
	rm /storage/.kodi/userdata/Database/Addons19.db
	rm /storage/.kodi/userdata/Database/saltscache.db-wal
	rm /storage/.kodi/userdata/Database/saltscache.db-shm
	rm /storage/.kodi/userdata/Database/saltscache.db
	cp /storage/.kodi/userdata/addon_data/plugin.video.genesis/favourites.db /storage/.kodi/userdata/addon_data/plugin.video.specto/favourites.db
	sleep 3
	myInfo 'Instellingen Updated - AFK-Box herstart nu!'
	sleep 3
	systemctl stop xbmc.service
	cp /storage/.kodi/addons/script.afkboxtools/resources/ViewModes6.db /storage/.kodi/userdata/Database/ViewModes6.db
	systemctl start xbmc.service
fi

if [[ "$1" == "clean" ]]; then
	myInfo 'Opschonen verouderde addons'
    rm -rf /var/media/STORAGE2/*
	sleep 5
	myInfo 'Add-ons Opschonen geslaagd'
fi

if [[ "$1" == "cleanthumb" ]]; then
	myInfo 'Afbeeldingen verwijderen'
	rm /storage/.kodi/userdata/Database/Textures13.db
	rm -rf /storage/.kodi/userdata/Thumbnails/*
	sleep 3
	myInfo 'Afbeeldingen verwijderd - AFK-Box herstart nu!'
	sleep 3
	systemctl stop xbmc.service
	cp /storage/.kodi/addons/script.afkboxtools2/resources/ViewModes6.db /storage/.kodi/userdata/Database/ViewModes6.db
	systemctl start xbmc.service
fi

if [[ "$1" == "backup" ]]; then
	myInfo 'Herinstallatie AFK-Box'
	cp /storage/backup/BackupAFKb0x11.tar /storage/.restore/BackupAFKb0x11.tar
	sleep 15
	myInfo 'Herinstallatie Bijna klaar!'
	sleep 15
	myInfo 'Herinstallatie Voltooid - AFK-Box herstart nu!'
	sleep 15
	reboot
fi

if [[ "$1" == "favba" ]]; then
	myInfo 'Favorieten Backupen'
	cp /storage/.kodi/userdata/addon_data/plugin.video.genesis/settings.db /storage/settings.db
	sleep 3
	myInfo 'Favorieten zijn gebackupt!'
fi

if [[ "$1" == "favre" ]]; then
	myInfo 'Favorieten Herstellen'
	cp /storage/settings.db /storage/.kodi/userdata/addon_data/plugin.video.genesis/settings.db
	sleep 3
	myInfo 'Favorieten zijn hersteld!'
fi