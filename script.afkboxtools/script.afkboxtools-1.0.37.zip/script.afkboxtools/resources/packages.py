############################################################################
#
#  Copyright 2015 AFK-Box
#
############################################################################


import xbmc, xbmcgui
import shutil

localtxt1 = 'Add-Ons Opschonen'
localtxt2 = 'Add-ons Opschonen bijna klaar'
localtxt3 = 'Weet u zeker dat u de add-ons wilt opschonen?'

destpath=xbmc.translatePath(os.path.join('special://home/addons/packages',''))

class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno(localtxt1, localtxt3):
      shutil.rmtree(destpath)
      os.mkdir(destpath)
      self.close()

      xbmc.executebuiltin('RunScript(special://home/addons/script.afkboxtools/resources/afkboxscript.py,clean)')
      xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Onderhoud)")



mydisplay = MyClass()
del mydisplay

