import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL3NpbGVudGh1bnRlci5zcnZlLmlvL3NreW5ldC9tYWluaG9tZS54bWw=')
addon = xbmcaddon.Addon('plugin.video.SkyNet')