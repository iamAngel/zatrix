import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL21hdmVyaWNrcmVwby5uZXQvZGF0YS9ob21lL3NreW5ldC9tYWluaG9tZS54bWw=')
addon = xbmcaddon.Addon('plugin.video.SkyNet')