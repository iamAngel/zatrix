import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,datetime,os,json,base64,plugintools
import xbmcvfs,zipfile
import xml.etree.ElementTree as ElementTree
reload(sys)
sys.setdefaultencoding('utf8')
SKIN_VIEW_FOR_MOVIES="515"
addonDir = plugintools.get_runtime_path()
hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
       'Accept-Encoding': 'none',
       'Accept-Language': 'en-US,en;q=0.8',
       'Connection': 'keep-alive'}

global kontroll
background = "YmFja2dyb3VuZC5wbmc=" #background.png
defaultlogo = "ZGVmYXVsdGxvZ28ucG5n" #defaultlogo.png
hometheater = "aG9tZXRoZWF0ZXIuanBn"
noposter = "bm9wb3N0ZXIucG5n"
theater = "dGhlYXRlci5qcGc="
addonxml = "YWRkb24ueG1s"
addonpy = "ZGVmYXVsdC5weQ=="
icon = "aWNvbi5wbmc="
fanart = "ZmFuYXJ0LmpwZw=="
message = "VU5BVVRIT1JJWkVEIEVESVQgT0YgQURET04h"
def run():
	global pnimi
	global televisioonilink
	global filmilink
	global andmelink
	global lehekylg
	global LOAD_LIVE
	global vanemalukk
	global vaestrid
	global stvypo

	kasutajanimi=plugintools.get_setting(get_live("VXNlcm5hbWU="))
	salasona=plugintools.get_setting(vod_channels("UGFzc3dvcmQ="))
	if not kasutajanimi or not salasona:
		count = 0
		while True:
			count = count + 1
			plugintools.log(vod_channels("UmFwaWRUZXN0"))
			plugintools.open_settings_dialog()
			kasutajanimi=plugintools.get_setting(get_live("VXNlcm5hbWU="))
			salasona=plugintools.get_setting(vod_channels("UGFzc3dvcmQ="))
			if kasutajanimi and salasona:
				break
			elif count == 2:
				sys.exit()
			else:
				plugintools.message(vod_channels("Tm90aWNl"), vod_channels("VnVsIHV3IEdlYnJ1aWtlcnNuYWFtIGVuIFdhY2h0d29vcmQgaW4u"))

	vanemalukk=plugintools.get_setting(sync_data("UGFyZW50YWxMb2Nr"))
	vaestrid=str(plugintools.get_setting(sync_data("RGlzcGxheUlE")))
	stvypo=str(plugintools.get_setting(sync_data("U3RyZWFtX1R5cGU=")))
	lehekylg=get_live("aHR0cDovLzE4NS4xNDcuMTIuMTQ3")
	pordinumber=get_live("ODA4MA==")
	pnimi=get_live("SVBUVg==")
	LOAD_LIVE = os.path.join( plugintools.get_runtime_path() , get_live("cmVzb3VyY2Vz") , vod_channels("bWVkaWE=") )
	plugintools.log(pnimi+get_live("U3RhcnRpbmcgdXA="))
	televisioonilink = get_live("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfbGl2ZV9jYXRlZ29yaWVz")%(lehekylg,pordinumber,kasutajanimi,salasona)
	filmilink = vod_channels("JXM6JXMvZW5pZ21hMi5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXMmdHlwZT1nZXRfdm9kX2NhdGVnb3JpZXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
	andmelink = vod_channels("JXM6JXMvcGxheWVyX2FwaS5waHA/dXNlcm5hbWU9JXMmcGFzc3dvcmQ9JXM=")%(lehekylg,pordinumber,kasutajanimi,salasona)
	if get_live("QUZLLUlQVFYgQnJvd3Nlcg==") not in open(addonDir+"/"+sync_data("YWRkb24ueG1s")).read():
		check_user()

	params = plugintools.get_params()
	if params.get("action") is None:
		peamenyy(params)
	else:
		action = params.get("action")
		exec action+"(params)"
	plugintools.close_item_list()

def peamenyy(params):
	plugintools.log(pnimi+vod_channels("TWFpbiBNZW51")+repr(params))
	load_channels()
	if not lehekylg:
		plugintools.open_settings_dialog()
	channels = kontroll()
	if channels == 1:
		plugintools.log(pnimi+vod_channels("TG9naW4gU3VjY2Vzcw=="))
		plugintools.add_item( action=vod_channels("ZXhlY3V0ZV9haW5mbw=="),  title=vod_channels("TWlqbiBBY2NvdW50") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) , folder=True )
		plugintools.add_item( action=vod_channels("c2VjdXJpdHlfY2hlY2s="),  title=vod_channels("TGl2ZSBUViBLYW5hbGVu") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bGl2ZXR2LnBuZw==")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) , folder=True )
		plugintools.add_item( action=vod_channels("ZGV0ZWN0X21vZGlmaWNhdGlvbg=="), title=vod_channels("VmlkZW8gb24gRGVtYW5k") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=")) , folder=True )
		plugintools.add_item( action=vod_channels("bGljZW5zZV9jaGVjaw=="), title=vod_channels("SW5zdGVsbGluZ2Vu") , thumbnail=os.path.join(LOAD_LIVE,vod_channels("c2V0dGluZ3MucG5n")) , fanart=os.path.join(LOAD_LIVE,vod_channels("YmFja2dyb3VuZC5wbmc=") ), folder=False )
		plugintools.set_view( plugintools.LIST )
	else:
		plugintools.log(pnimi+vod_channels("SW5sb2dnZW4gTWlzbHVrdA=="))
		plugintools.message(vod_channels("SW5sb2dnZW4gTWlzbHVrdA=="), vod_channels("Q29udHJvbGVlciB1dyBHZWJydWlrZXJzbmFhbSBvZiBXYWNodHdvb3JkLgpOZWVtIGFuZGVycyBjb250YWN0IG9wIG1ldCB1dyAlcyBQcm92aWRlciE=")%(pnimi))
		plugintools.open_settings_dialog()
		sys.exit()

def license_check(params):
	plugintools.log(pnimi+get_live("U2V0dGluZ3MgbWVudQ==")+repr(params))
	plugintools.open_settings_dialog()
def security_check(params):
	plugintools.log(pnimi+sync_data("TGl2ZSBNZW51")+repr(params))
	request = urllib2.Request(televisioonilink, headers=hdr)
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	count = 0
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		if vaestrid == "2":
			count = count + 1
			counte = str(count)
		elif vaestrid == "1":
			counte = channel.find(get_live("Y2F0ZWdvcnlfaWQ=")).text
		kanalinimi = channel.find(get_live("dGl0bGU=")).text
		kanalinimi = base64.b64decode(kanalinimi)
		if vaestrid != "0":
			kanalinimi = "[COLOR green]" + counte + "[/COLOR] - "+kanalinimi
		kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
		plugintools.add_item( action=get_live("c3RyZWFtX3ZpZGVv"), title=kanalinimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bGl2ZXR2LnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
	plugintools.set_view( plugintools.LIST )
def detect_modification(params):
	plugintools.log(pnimi+vod_channels("Vk9EIE1lbnUg")+repr(params))
	request = urllib2.Request(filmilink, headers=hdr)
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	count = 0
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		if vaestrid == "2":
			count = count + 1
			counte = str(count)
		elif vaestrid == "1":
			counte = channel.find(get_live("Y2F0ZWdvcnlfaWQ=")).text
		filminimi = channel.find(get_live("dGl0bGU=")).text
		filminimi = base64.b64decode(filminimi)
		filminimi = filminimi.encode("utf-8")
		if vaestrid != "0":
			filminimi = "[COLOR green]" + counte + "[/COLOR] - "+filminimi
		kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
		engma = sync_data("c2NhdF9pZA=="), sync_data("Z2V0X3ZvZF9zY2F0ZWdvcmllcw==")
		if any(stlru in kategoorialink for stlru in engma):
			plugintools.add_item( action=vod_channels("c3ViX21vZGlmaWNhdGlvbg=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
		else:
#			if filminimi == sync_data("QWxs"):
#				continue
			plugintools.add_item( action=vod_channels("Z2V0X215YWNjb3VudA=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
	plugintools.set_view( plugintools.LIST )

def sub_modification(params):
	plugintools.log(pnimi+vod_channels("U1VCVk9EIE1lbnUg")+repr(params))
	purl = params.get(get_live("dXJs"))
	request = urllib2.Request(purl, headers=hdr)
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	count = 0
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		if vaestrid == "2":
			count = count + 1
			counte = str(count)
		elif vaestrid == "1":
			counte = channel.find(get_live("Y2F0ZWdvcnlfaWQ=")).text
		filminimi = channel.find(get_live("dGl0bGU=")).text
		filminimi = base64.b64decode(filminimi)
		filminimi = filminimi.encode("utf-8")
		if vaestrid != "0":
			filminimi = "[COLOR green]" + counte + "[/COLOR] - "+filminimi
		kategoorialink = channel.find(vod_channels("cGxheWxpc3RfdXJs")).text
		plugintools.add_item( action=vod_channels("Z2V0X215YWNjb3VudA=="), title=filminimi , url=kategoorialink , thumbnail=os.path.join(LOAD_LIVE,vod_channels("dm9kLnBuZw==")) , fanart=os.path.join(LOAD_LIVE,sync_data("dGhlYXRlci5qcGc=")) , folder=True )
	plugintools.set_view( plugintools.LIST )

def stream_video(params):
	plugintools.log(pnimi+sync_data("TGl2ZSBDaGFubmVscyBNZW51IA==")+repr(params))
	if get_live("QUZLLUlQVFYgQnJvd3Nlcg==") not in open(addonDir+"/"+sync_data("YWRkb24ueG1s")).read():
		check_user()
	if vanemalukk == "true":
		pealkiri = params.get(sync_data("dGl0bGU="))
		vanema_lukk(pealkiri)
	url = params.get(get_live("dXJs"))
	request = urllib2.Request(url, headers=hdr)
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	count = 0
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		if vaestrid == "2":
			count = count + 1
			counte = str(count)
		kanalinimi = channel.find(get_live("dGl0bGU=")).text
		kanalinimi = base64.b64decode(kanalinimi)
		kanalinimi = kanalinimi.partition("[")
		striimilink = channel.find(get_live("c3RyZWFtX3VybA==")).text
		pilt = channel.find(vod_channels("ZGVzY19pbWFnZQ==")).text
		kava = kanalinimi[1]+kanalinimi[2]
		kava = kava.partition("]")
		kava = kava[2]
		kava = kava.partition("   ")
		kava = kava[2]
		if vaestrid == "1":
			shou = "[COLOR green]" + cls_strids(striimilink) + "[/COLOR] - "+get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(kanalinimi[0])+"- [COLOR firebrick]" + kava + "[/COLOR]"
		elif vaestrid == "2":
			shou = "[COLOR green]" + counte + "[/COLOR] - "+get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(kanalinimi[0])+"- [COLOR firebrick]" + kava + "[/COLOR]"
		else:
			shou = get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(kanalinimi[0])+"- [COLOR firebrick]" + kava + "[/COLOR]"
		kirjeldus = channel.find(sync_data("ZGVzY3JpcHRpb24=")).text
		if kirjeldus:
			kirjeldus = base64.b64decode(kirjeldus)
			nyyd = kirjeldus.partition("(")
			nyyd = sync_data("TnU6IA==") +nyyd[0]
			jargmine = kirjeldus.partition(")\n")
			jargmine = jargmine[2].partition("(")
			jargmine = sync_data("Vm9sZ2VuZGU6IA==") +jargmine[0]
			kokku = nyyd+jargmine
		else:
			kokku = ""
		if pilt:
			plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=striimilink, thumbnail=pilt, plot=kokku, fanart=os.path.join(LOAD_LIVE,vod_channels("aG9tZXRoZWF0ZXIuanBn")), extra="", isPlayable=True, folder=False )
		else:
			plugintools.add_item( action=sync_data("cnVuX2Nyb25qb2I="), title=shou , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,sync_data("ZGVmYXVsdGxvZ28ucG5n")) , plot=kokku, fanart=os.path.join(LOAD_LIVE,sync_data("aG9tZXRoZWF0ZXIuanBn")) , extra="", isPlayable=True, folder=False )
	plugintools.set_view( plugintools.EPISODES )
	xbmc.executebuiltin(vod_channels("Q29udGFpbmVyLlNldFZpZXdNb2RlKDUwMyk="))

def get_myaccount(params):
	plugintools.log(pnimi+get_live("Vk9EIGNoYW5uZWxzIG1lbnUg")+repr(params))
	if vanemalukk == "true":
		pealkiri = params.get(sync_data("dGl0bGU="))
		vanema_lukk(pealkiri)
	purl = params.get(get_live("dXJs"))
	request = urllib2.Request(purl, headers=hdr)
	u = urllib2.urlopen(request)
	tree = ElementTree.parse(u)
	rootElem = tree.getroot()
	count = 0
	for channel in tree.findall(sync_data("Y2hhbm5lbA==")):
		if vaestrid == "2":
			count = count + 1
			counte = str(count)
		pealkiri = channel.find(get_live("dGl0bGU=")).text
		pealkiri = base64.b64decode(pealkiri)
		pealkiri = pealkiri.encode("utf-8")
		striimilink = channel.find(sync_data("c3RyZWFtX3VybA==")).text
		if vaestrid == "1":
			pealkiri = "[COLOR green]" + cls_strids(striimilink) + "[/COLOR] - "+get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(pealkiri)
		if vaestrid == "2":
			pealkiri = "[COLOR green]" + counte+ "[/COLOR] - "+get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(pealkiri)
		else:
			pealkiri = get_live("W0NPTE9SIHN0ZWVsYmx1ZV0lcyBbL0NPTE9SXQ==")%(pealkiri)
		pilt = channel.find(sync_data("ZGVzY19pbWFnZQ==")).text
		kirjeldus = channel.find(vod_channels("ZGVzY3JpcHRpb24=")).text
		if kirjeldus:
			kirjeldus = base64.b64decode(kirjeldus)
			kirjeldus = kirjeldus.encode("utf-8")
		else:
			kirjeldus = ""
		if pilt:
			plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=pilt, plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,"theater.jpg") , extra="", isPlayable=True, folder=False )
		else:
			plugintools.add_item( action="restart_service", title=pealkiri , url=striimilink, thumbnail=os.path.join(LOAD_LIVE,"noposter.png"), plot=kirjeldus, fanart=os.path.join(LOAD_LIVE,"theater.jpg"), extra="", isPlayable=True, folder=False )
		plugintools.set_view( plugintools.MOVIES )
		xbmc.executebuiltin('Container.SetViewMode(515)')

def cls_strids(striimilink):
	striimiim = striimilink.split('/')
	striimmidim = striimiim[6]
	striimmidin = striimmidim.split('.')
	striimmidi = striimmidin[0]
	return striimmidi


def run_cronjob(params):
	kasutajanimi=plugintools.get_setting(get_live("VXNlcm5hbWU="))
	salasona=plugintools.get_setting(vod_channels("UGFzc3dvcmQ="))
	lopplink = params.get(vod_channels("dXJs"))
	lopplink = lopplink.replace(vod_channels("JXVzZXJuYW1l"), vod_channels("a2FzdXRhamFuaW1p"))
	lopplink = lopplink.replace(vod_channels("JXBhc3N3b3Jk"), vod_channels("c2FsYXNvbmE="))
	if stvypo == "1":
		lopplink = lopplink.replace(vod_channels("LnRz"), vod_channels("Lm0zdTg="))
	listitem = xbmcgui.ListItem(path=lopplink)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def sync_data(channel):
	video = base64.b64decode(channel)
	return video

def restart_service(params):
	lopplink = params.get(vod_channels("dXJs"))
	plugintools.play_resolved_url( lopplink )

def grab_epg():
	req = urllib2.Request(andmelink)
	req.add_header(sync_data("VXNlci1BZ2VudA==") , vod_channels("S29kaSBwbHVnaW4gYnkgUmFwaWRJUFRW"))
	response = urllib2.urlopen(req)
	link=response.read()
	jdata = json.loads(link.decode('utf8'))
	response.close()
	if jdata:
		plugintools.log(pnimi+sync_data("amRhdGEgbG9hZGVkIA=="))
		return jdata

def kontroll():
	randomstring = grab_epg()
	kasutajainfo = randomstring[sync_data("dXNlcl9pbmZv")]
	kontroll = kasutajainfo[get_live("YXV0aA==")]
	return kontroll

def get_live(channel):
	video = base64.b64decode(channel)
	return video

def execute_ainfo(params):
	plugintools.log(pnimi+get_live("TXkgYWNjb3VudCBNZW51IA==")+repr(params))
	andmed = grab_epg()
	kasutajaAndmed = andmed[sync_data("dXNlcl9pbmZv")]
	seis = kasutajaAndmed[get_live("c3RhdHVz")]
	aegub = kasutajaAndmed[sync_data("ZXhwX2RhdGU=")]
	if aegub:
		aegub = datetime.datetime.fromtimestamp(int(aegub)).strftime('%d/%m/%Y %H:%M')
	else:
		aegub = vod_channels("TmV2ZXI=")
	leavemealone = kasutajaAndmed[get_live("bWF4X2Nvbm5lY3Rpb25z")]
	polarbears = kasutajaAndmed[sync_data("dXNlcm5hbWU=")]
	aettb = kasutajaAndmed[sync_data("aXNfdHJpYWw=")]
	cettl = kasutajaAndmed[sync_data("Y3JlYXRlZF9hdA==")]
	aeptl = kasutajaAndmed[sync_data("YWN0aXZlX2NvbnM=")]
	if aettb == 0:
		aettb = "Yes"
	else:
		aettb = "No"
	if cettl:
			cettl = datetime.datetime.fromtimestamp(int(cettl)).strftime('%d/%m/%Y %H:%M')
	else:
		 aegub = vod_channels("Ti9B")
	plugintools.add_item( action="",   title=sync_data("W0NPTE9SID0gd2hpdGVdR2VicnVpa2Vyc25hYW06IFsvQ09MT1Jd")+polarbears , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=sync_data("W0NPTE9SID0gd2hpdGVdU3RhdHVzOiBbL0NPTE9SXQ==")+seis , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=get_live("W0NPTE9SID0gd2hpdGVdU3RhcnRkYXR1bTogWy9DT0xPUl0=")+cettl , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=get_live("W0NPTE9SID0gd2hpdGVdRWluZGRhdHVtOiBbL0NPTE9SXQ==")+aegub , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=get_live("W0NPTE9SID0gd2hpdGVdVHJpYWw6IFsvQ09MT1Jd")+aettb , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=vod_channels("W0NPTE9SID0gd2hpdGVdTWF4IENvbm5lY3RpZXM6IFsvQ09MT1Jd")+leavemealone , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.add_item( action="",   title=vod_channels("W0NPTE9SID0gd2hpdGVdQWN0aXZlIENvbm5lY3RpZXM6IFsvQ09MT1Jd")+aeptl , thumbnail=os.path.join(LOAD_LIVE,vod_channels("bXlhY2MucG5n")) , fanart=os.path.join(LOAD_LIVE,sync_data("YmFja2dyb3VuZC5wbmc=")) , folder=False )
	plugintools.set_view( plugintools.LIST )

def vanema_lukk(name):
	plugintools.log(pnimi+sync_data("UGFyZW50YWwgbG9jayA="))
	a = 'XXX', 'Adult', 'Adults','ADULT','ADULTS','adult','adults','Porn','PORN','porn','Porn','xxx'
	if any(s in name for s in a):
		xbmc.executebuiltin((u'XBMC.Notification("Parental Lock", "Channels may contain adult content", 2000)'))
		text = plugintools.keyboard_input(default_text="", title=get_live("UGFyZW50YWwgbG9jaw=="))
		if text == plugintools.get_setting(sync_data("UGFyZW50YWxDb2Rl")):
			return
		else:
			sys.exit()
	else:
		name = ""

def check_user():
	plugintools.message(get_live("RVJST1I="),vod_channels("VU5BVVRIT1JJWkVEIEVESVQgT0YgQURET04h"))
	sys.exit()

def load_channels():
	statinfo = os.stat(LOAD_LIVE+"/"+get_live("YmFja2dyb3VuZC5wbmc="))

def vod_channels(channel):
	video = base64.b64decode(channel)
	return video
run()
