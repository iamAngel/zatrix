#!/bin/sh
#kodi-send -a "Notification(afkboxscript.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(Verwerken van Opdracht:,$1,$TIME,/storage/.kodi/addons/plugin.program.afkinstallerX/resources/afkboxscript.png)" &> /dev/null
  echo $1
}

checkUSB(){
	USB=$(df | grep /dev/sda)
	if [[ "$USB" == "" ]]; then
		myInfo 'geen USB apparaat gevonden!'
		exit
	fi
}

if [[ "$1" == "clean" ]]; then
	myInfo 'Opschonen verouderde addons'
	rm -rf /var/media/STORAGE2/*
	rm -rf '/storage/.kodi/addons/plugin.video.titan'
	rm -rf '/storage/.kodi/addons/plugin.video.dss'
	rm -rf '/storage/.kodi/addons/plugin.video.genesis'
	rm -rf '/storage/.kodi/addons/plugin.video.onlydutch'
	rm -rf '/storage/.kodi/addons/service.system.wetek-cec'
	rm -rf '/storage/.kodi/addons/plugin.audio.spotify'
	rm -rf '/storage/.kodi/addons/plugin.video.phstreams'
	rm -rf '/storage/.kodi/addons/plugin.video.nlplks'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.titan'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.audio.spotify'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.dss'
	rm -rf '/storage/.kodi/userdata/addon_data/service.system.wetek-cec'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.genesis'
	rm -rf '/storage/.kodi/userdata/addon_data/plugin.video.phstreams'
	rm -rf '/storage/.kodi/addons/repository.xbmchub'
	rm -rf '/storage/.kodi/addons/repository.tknorris.beta'
	rm -rf '/storage/.kodi/addons/repository.metalkettle'
	rm -rf '/storage/.kodi/addons/repository.shani'
	rm -rf '/storage/.kodi/addons/repository.echo'
	rm -rf '/storage/.kodi/addons/repository.Kinkin'
	sleep 5
	myInfo 'Opschonen geslaagd - Herstarten'
	sleep 3
	reboot
fi

if [[ "$1" == "cleanthumb" ]]; then
	myInfo 'Afbeeldingen verwijderen'
	rm /storage/.kodi/userdata/Database/Textures13.db
	rm -rf /storage/.kodi/userdata/Thumbnails/*
	sleep 3
	myInfo 'Afbeeldingen verwijderd - Herstarten'
	sleep 3
    reboot
fi